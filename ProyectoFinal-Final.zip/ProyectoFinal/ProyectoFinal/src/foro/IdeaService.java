package foro;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import main.PersistenciaUtils;

public class IdeaService {
    private List<Idea> ideas = new ArrayList<>();
    private static final String ARCHIVO_IDEAS = PersistenciaUtils.getRutaMuro() + File.separator + "ideas.dat";

    public IdeaService() { cargarIdeas(); }

    public List<Idea> getIdeas() { return ideas; }

    public List<Idea> getIdeasPendientes() {
        List<Idea> pendientes = new ArrayList<>();
        for (Idea idea : ideas) {
            if (idea.getEstado() == Idea.Estado.PENDIENTE) pendientes.add(idea);
        }
        return pendientes;
    }

    public List<Idea> getIdeasAprobadas() {
        List<Idea> aprobadas = new ArrayList<>();
        for (Idea idea : ideas) {
            if (idea.getEstado() == Idea.Estado.APROBADA) aprobadas.add(idea);
        }
        return aprobadas;
    }

    public void agregarIdea(Idea idea) {
        ideas.add(idea);
        guardarIdeas();
    }

    public void aprobarIdea(Idea idea) {
        idea.aprobar();
        guardarIdeas();
    }

    public void desaprobarIdea(Idea idea) {
        idea.desaprobar();
        guardarIdeas();
    }

    public void eliminarIdea(Idea idea) {
        ideas.remove(idea);
        guardarIdeas();
    }

    public void guardarIdeas() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_IDEAS))) {
            oos.writeObject(ideas);
        } catch (IOException e) {
            guardarErrorEnTxt("Error guardando ideas: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarIdeas() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_IDEAS))) {
            ideas = (List<Idea>) ois.readObject();
        } catch (Exception e) {
            ideas = new ArrayList<>();
            guardarErrorEnTxt("Error cargando ideas: " + e.getMessage());
        }
    }

    private void guardarErrorEnTxt(String mensaje) {
        String archivoErrores = PersistenciaUtils.getRutaMuro() + File.separator + "errores_serializacion.txt";
        try (FileWriter fw = new FileWriter(archivoErrores, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(java.time.LocalDateTime.now() + " - " + mensaje);
        } catch (IOException ex) {
            // No se puede hacer más si falla
        }
    }
}