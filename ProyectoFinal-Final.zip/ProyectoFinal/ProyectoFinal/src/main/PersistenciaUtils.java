package main;

import java.io.File;

public class PersistenciaUtils {
    public static String getRutaMuro() {
        // Obtener el directorio "home" del usuario
        String userHome = System.getProperty("user.home");
        String documentosPath = userHome + File.separator + "Documentos";
        System.out.println("Ruta base (Documentos): " + documentosPath);
        
        // Verificar si existe "Documentos"
        File documentosDir = new File(documentosPath);
        if (!documentosDir.exists()) {
            // Si no existe, intentar con "Documents"
            documentosPath = userHome + File.separator + "Documents";
            System.out.println("Intentando con: " + documentosPath);
            documentosDir = new File(documentosPath);
            if (!documentosDir.exists()) {
                System.out.println("No se encontró el directorio de documentos.");
                return null; // Retorna null si no se encuentra ningún directorio
            }
        }
        
        // Construir la ruta completa: Documentos/compartida/muro
        String carpetaCompartida = documentosPath + File.separator + "compartida";
        String carpetaMuro = carpetaCompartida + File.separator + "muro";
        File directorioMuro = new File(carpetaMuro);
        
        // Crear el directorio "muro" si no existe
        if (!directorioMuro.exists()) {
            System.out.println("Creando directorio: " + carpetaMuro);
            boolean creado = directorioMuro.mkdirs();
            if (creado) {
                System.out.println("Directorio creado exitosamente.");
            } else {
                System.out.println("No se pudo crear el directorio.");
            }
        }
        
        // Devolver la ruta completa
        return carpetaMuro;
    }
}