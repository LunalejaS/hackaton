package auth;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import main.PersistenciaUtils;

public class AuthService {
    private List<Usuario> usuarios = new ArrayList<>();
    private static final String ARCHIVO_USUARIOS = PersistenciaUtils.getRutaMuro() + File.separator + "usuarios.dat";

    public AuthService() {
        cargarUsuarios();
        boolean adminExiste = false;
        for (Usuario u : usuarios) {
            if (u.getUsername().equals("admin")) {
                adminExiste = true;
                break;
            }
        }
        if (!adminExiste) {
            usuarios.add(new Usuario("admin", "admin123"));
            guardarUsuarios();
        }
    }

    public boolean registrarUsuario(String username, String password) {
        for (Usuario u : usuarios) {
            if (u.getUsername().equals(username)) {
                return false;
            }
        }
        usuarios.add(new Usuario(username, password));
        guardarUsuarios();
        return true;
    }

    public Usuario iniciarSesion(String username, String password) {
        for (Usuario u : usuarios) {
            if (u.getUsername().equals(username) && u.checkPassword(password)) {
                return u;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void cargarUsuarios() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_USUARIOS))) {
            usuarios = (List<Usuario>) ois.readObject();
        } catch (Exception e) {
            usuarios = new ArrayList<>();
            guardarErrorEnTxt("Error cargando usuarios: " + e.getMessage());
        }
    }

    private void guardarUsuarios() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_USUARIOS))) {
            oos.writeObject(usuarios);
        } catch (IOException e) {
            guardarErrorEnTxt("Error guardando usuarios: " + e.getMessage());
        }
    }

    private void guardarErrorEnTxt(String mensaje) {
        String archivoErrores = PersistenciaUtils.getRutaMuro() + File.separator + "errores_serializacion.txt";
        try (FileWriter fw = new FileWriter(archivoErrores, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(java.time.LocalDateTime.now() + " - " + mensaje);
        } catch (IOException ex) {
            // No hay mucho más que hacer si falla
        }
    }
}